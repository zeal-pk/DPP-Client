"use client";
import { useState, useEffect, use } from "react";
import NavBar from "@/components/navBar";
import axios from "axios";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import {
  ThemeProvider,
  FlexibleColumnLayout,
  List,
  StandardListItem,
} from "@ui5/webcomponents-react";

export default function Home() {
  let [productId, setProductId] = useState();
  let [productKeys, setProductKeys] = useState([]);
  let [selectedKey, setSelectedKey] = useState();
  let [productDetails, setProductDetails] = useState();

  async function getDataKeys(id) {
    let token = localStorage.getItem("access_token");
    await axios
      .get(`http://localhost:9000/getProduct/${id}`, {
        headers: {
          Authorization: "Bearer " + token,
        },
      })
      .then((response) => {
        let keys = [];
        let data = response.data;
        setProductDetails(response.data);
        Object.keys(data).forEach(function (key, index) {
          keys.push(key);
          setProductKeys(keys);
        });
        console.log(productKeys);
      });
  }

  function getSecondaryKey(getDataKeys) {
    // const additionslT = (getDataKeys) => {
    //   return Object.keys(getDataKeys).map((key) => {
    //     return Object.keys(productDetails[key]).map((child) => {
    //       // return (
    //       //   <CardContent className="materialComposition-chart-card-content">
    //       //     {child}: {data[key][child]}
    //       //   </CardContent>
    //       // );
    //       console.log(child);
    //     });
    //   });
    // };
    console.log(getDataKeys);
  }

  const onStartColumnClick = (e) => {
    // setSelectedMovie(e.detail);
    console.log(e.detail.item.dataset.movies);
  };

  useEffect(() => {
    getDataKeys(productId);
  }, [productId]);

  return (
    <div className="main">
      <NavBar />

      <Stack spacing={2} direction="row" sx={{ width: 520, margin: 1 }}>
        <TextField
          id="outlined-basic"
          label="Email Address"
          variant="outlined"
          onChange={(e) => setProductId(e.target.value)}
        />
        <Button
          variant="contained"
          onClick={() => {
            getDataKeys(productKeys);
          }}
        >
          Get product Details
        </Button>
      </Stack>
      {getSecondaryKey(productKeys)}
      <ThemeProvider>
        <FlexibleColumnLayout
          startColumn={
            <List
              headerText="Start Column List"
              onItemClick={setSelectedKey(e.data)}
            >
              {productKeys.map((key) => {
                return <StandardListItem key={key}>{key}</StandardListItem>;
              })}
            </List>
          }
          layout="ThreeColumnsMidExpanded"
          midColumn={
            <List headerText="Mid Column List">
              <StandardListItem>List Item 1</StandardListItem>
            </List>
          }
          onLayoutChange={function _a() {}}
          endColumn={
            <List headerText="End Column List">
              <StandardListItem>List Item 1</StandardListItem>
              <StandardListItem>List Item 2</StandardListItem>
              <StandardListItem>List Item 3</StandardListItem>
            </List>
          }
        />
      </ThemeProvider>
    </div>
  );
}
